/* This file is for additional client-side JS logic not directly tied to a specific template. */
document.addEventListener('DOMContentLoaded', function() {
    // Lazy loading for product images on index.html
    const lazyImages = document.querySelectorAll('img[data-src].lazy');
    if ('IntersectionObserver' in window) {
        let lazyImageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    let lazyImage = entry.target;
                    lazyImage.src = lazyImage.dataset.src;
                    lazyImage.classList.remove('lazy');
                    lazyImageObserver.unobserve(lazyImage);
                }
            });
        }, {
            rootMargin: '0px 0px 200px 0px' // Load images when 200px away from viewport
        });

        lazyImages.forEach(function(lazyImage) {
            lazyImageObserver.observe(lazyImage);
        });
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        lazyImages.forEach(img => {
            img.src = img.dataset.src;
            img.classList.remove('lazy');
        });
    }

    // Dark Mode Toggle Logic
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        const icon = darkModeToggle.querySelector('i');
        // Check for saved dark mode preference and apply on load
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
            icon.classList.replace('fa-moon', 'fa-sun'); // Sun icon for dark mode
        } else {
            document.body.classList.remove('dark-mode');
            icon.classList.replace('fa-sun', 'fa-moon'); // Moon icon for light mode
        }

        darkModeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('darkMode', 'true');
                icon.classList.replace('fa-moon', 'fa-sun'); // Sun icon for dark mode
                flash('Embrace the shadow, you magnificent fiend.', 'info');
            } else {
                localStorage.setItem('darkMode', 'false');
                icon.classList.replace('fa-sun', 'fa-moon'); // Moon icon for light mode
                flash('Back to the glaring light, as a worm exposed.', 'info');
            }
        });
    }
});

// Global flash function from layout.html, made global for broader use
function flash(message, category) {
    const container = document.querySelector('.container');
    const flashDiv = document.createElement('div');
    flashDiv.className = `alert alert-${category}`;
    flashDiv.textContent = message;
    
    const flashMessagesContainer = document.querySelector('.flash-messages') || document.createElement('div');
    if (!document.querySelector('.flash-messages')) {
        flashMessagesContainer.className = 'flash-messages';
        // Prepend so new messages appear at the top of the stack
        container.prepend(flashMessagesContainer);
    }
    // Append to the container so messages stack
    flashMessagesContainer.appendChild(flashDiv);

    // Make sure flash message counts update
    // You might want to remove old flashes to keep the count clean after 5s
    
    setTimeout(() => {
        flashDiv.style.opacity = '0';
        flashDiv.style.transition = 'opacity 0.5s ease-out';
        setTimeout(() => flashDiv.remove(), 500);
    }, 5000);
}